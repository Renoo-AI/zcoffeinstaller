﻿"use strict";

const DEFAULT_MENU = [
  ["Boissons Fraîches", "Citronnade", 3],
  ["Boissons Fraîches", "Jus Frais", 4.5],
  ["Zcoffee", "Express / Demi / Allongé", 2.5],
  ["Zcoffee", "Direct", 3.2],
  ["Zcoffee", "Cappuccino / Americano", 2.8],
  ["Zcoffee", "Spécial", 3.5],
  ["Chicha & Girac", "Chicha parfum", 4],
  ["Chicha & Girac", "Girac (XL)", 4.5],
  ["Chicha & Girac", "Chicha Vide", 3],
  ["Chicha & Girac", "Girac (XXL)", 5.5],
  ["Chicha & Girac", "Chicha Cocktail", 4.5],
  ["Chicha & Girac", "Girac (M)", 3.5],
  ["Eaux & Soft", "Canette", 2.5],
  ["Eaux & Soft", "Eau 1.5 L", 2],
  ["Eaux & Soft", "Eau 0.5 L", 1],
  ["Thé", "Thé", 2],
  ["Viennoiseries", "Cake", 1.5]
].map((x, i) => ({ id: "m" + i, category: x[0], name: x[1], price: x[2], stock: null, lowStock: 5, active: true }));

const KEY = "menux_caisse_oued_ellil_clean_v4";
const ARCHIVE_KEY = "menux_caisse_sales_archive_v1";
const CASHIER_KEY = "menux_caisse_cashiers_v4";
const CATALOG_KEY = "menux_caisse_catalog_v6";
const STOCK_KEY = "menux_caisse_stock_log_v1";
const INGREDIENTS_KEY = "menux_caisse_ingredients_v1";
const LOGS_KEY = "menux_caisse_audit_logs_v2";
const STARTING_CASH_KEY = "menux_caisse_starting_cash_v1";
const CLOSING_CASH_KEY = "menux_caisse_closing_cash_v1";
const ZOOM_KEY = "menux_caisse_ui_zoom_v1";
const TELEGRAM_TOKEN = "8830104614:AAHGyLaNZAPdCnPFeiwGuSCYKKESqYoTP2A";
let lastCartActivity = Date.now();

const DEFAULT_INGREDIENTS = [
  { id: "i_cafe", name: "Café Grain", unit: "g", stock: 2000, lowStock: 500 },
  { id: "i_maassel", name: "Maassel (Tabac)", unit: "g", stock: 1000, lowStock: 200 },
  { id: "i_charbon", name: "Charbon (Pièces)", unit: "pcs", stock: 300, lowStock: 50 },
  { id: "i_mbasel", name: "Mbasel (Embouts)", unit: "pcs", stock: 300, lowStock: 50 },
  { id: "i_eau15", name: "Bouteille Eau 1.5L", unit: "pcs", stock: 50, lowStock: 10 },
  { id: "i_eau05", name: "Bouteille Eau 0.5L", unit: "pcs", stock: 50, lowStock: 10 },
  { id: "i_canette", name: "Canette Soft", unit: "pcs", stock: 60, lowStock: 12 },
  { id: "i_cake", name: "Cake (Viennoiserie)", unit: "pcs", stock: 30, lowStock: 5 }
];

const RECIPES = {
  "Express / Demi / Allongé": [{ ingredientId: "i_cafe", qty: 14 }],
  "Direct": [{ ingredientId: "i_cafe", qty: 14 }],
  "Cappuccino / Americano": [{ ingredientId: "i_cafe", qty: 14 }],
  "Spécial": [{ ingredientId: "i_cafe", qty: 14 }],
  
  "Chicha parfum": [
    { ingredientId: "i_maassel", qty: 20 },
    { ingredientId: "i_charbon", qty: 3 },
    { ingredientId: "i_mbasel", qty: 1 }
  ],
  "Chicha Vide": [
    { ingredientId: "i_maassel", qty: 0 },
    { ingredientId: "i_charbon", qty: 3 },
    { ingredientId: "i_mbasel", qty: 1 }
  ],
  "Chicha Cocktail": [
    { ingredientId: "i_maassel", qty: 20 },
    { ingredientId: "i_charbon", qty: 3 },
    { ingredientId: "i_mbasel", qty: 1 }
  ],
  "Girac (M)": [
    { ingredientId: "i_maassel", qty: 15 },
    { ingredientId: "i_charbon", qty: 3 },
    { ingredientId: "i_mbasel", qty: 1 }
  ],
  "Girac (XL)": [
    { ingredientId: "i_maassel", qty: 25 },
    { ingredientId: "i_charbon", qty: 4 },
    { ingredientId: "i_mbasel", qty: 1 }
  ],
  "Girac (XXL)": [
    { ingredientId: "i_maassel", qty: 30 },
    { ingredientId: "i_charbon", qty: 5 },
    { ingredientId: "i_mbasel", qty: 1 }
  ],
  
  "Eau 1.5 L": [{ ingredientId: "i_eau15", qty: 1 }],
  "Eau 0.5 L": [{ ingredientId: "i_eau05", qty: 1 }],
  "Canette": [{ ingredientId: "i_canette", qty: 1 }],
  "Cake": [{ ingredientId: "i_cake", qty: 1 }]
};
const today = localDateKey();
const MASTER_PIN = atob("MjU4MA=="); // Owner Master PIN

let menu = loadCatalog();
let active = "Tous";
let query = "";
let historyQuery = "";
let cart = [];
let lastAction = null;
let currentReceiptOrder = null;
let activePaymentMethod = "Espèces";
let currentOrderMode = "Sur place";
let paidBuffer = "";
let uiZoom = loadUiZoom();

// Multi-Ticket Holds System (Hold & Resume up to 3 drafts)
let holds = []; // Array of hold structures: { id, time, sequence, cart }

// Security & Cashier Portal States
let cashiers = loadCashiers();
let activeCashier = null;
let selectedCashier = null;
let typedPin = "";
let failedPinAttempts = 0;
const LOCKOUT_KEY = "menux_caisse_lockout_until_v1";
const LOCKOUT_COUNT_KEY = "menux_caisse_lockout_count_v1";
let lockoutUntil = 0;
try {
  lockoutUntil = Number(localStorage.getItem(LOCKOUT_KEY)) || 0;
} catch (e) {}

function saveLockout(val) {
  lockoutUntil = val;
  try {
    localStorage.setItem(LOCKOUT_KEY, String(val));
  } catch (e) {}
}

function loadLockoutCount() {
  try {
    return Number(localStorage.getItem(LOCKOUT_COUNT_KEY)) || 0;
  } catch (e) {
    return 0;
  }
}

function saveLockoutCount(count) {
  try {
    localStorage.setItem(LOCKOUT_COUNT_KEY, String(count));
  } catch (e) {}
}

function getNextLockoutDuration(currentCount) {
  if (currentCount === 1) return 60 * 1000; // 60s
  if (currentCount === 2) return 300 * 1000; // 5 min
  if (currentCount === 3) return 900 * 1000; // 15 min
  if (currentCount === 4) return 1800 * 1000; // 30 min
  // Max is 30, then alternate starting back from 15 min, then 30 min, 15 min, 30 min...
  return (currentCount % 2 === 1) ? 900 * 1000 : 1800 * 1000;
}

function triggerNewLockout() {
  const currentCount = loadLockoutCount() + 1;
  saveLockoutCount(currentCount);
  
  const duration = getNextLockoutDuration(currentCount);
  saveLockout(Date.now() + duration);
  
  let label = "60s";
  if (duration === 300 * 1000) label = "5 min";
  else if (duration === 900 * 1000) label = "15 min";
  else if (duration === 1800 * 1000) label = "30 min";
  
  showToast(`Trop de tentatives! Bloqué ${label}`);
  failedPinAttempts = 0;
  
  logAuditEvent("Système Bloqué", `Trop d'échecs de saisie de code PIN. Cooldown: ${label}`);
}

async function sendTelegramNotification(text) {
  try {
    const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/getUpdates`);
    if (!response.ok) return;
    const resData = await response.json();
    if (!resData.ok || !resData.result) return;
    
    const chatIds = new Set();
    resData.result.forEach(update => {
      const msg = update.message || update.callback_query?.message;
      if (msg && msg.chat && msg.chat.id) {
        chatIds.add(msg.chat.id);
      }
    });
    
    for (const chatId of chatIds) {
      await fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: chatId,
          text: text,
          parse_mode: "HTML",
          disable_web_page_preview: true
        })
      });
    }
  } catch (e) {
    console.error("Telegram notify failed:", e);
  }
}

function telegramEscape(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function shouldNotifyTelegram(action) {
  const act = String(action || "").toLowerCase();
  return (
    act.includes("bloqué") ||
    act.includes("reset") ||
    act.includes("suppression") ||
    act.includes("logs effacés") ||
    act.includes("alarme")
  );
}

function buildSecurityTelegramMessage(event) {
  const time = new Date(event.time).toLocaleString("fr-FR", {
    dateStyle: "short",
    timeStyle: "short"
  });
  return [
    "<b>Zina Coffee | Alerte sécurité</b>",
    "",
    `<b>Action</b> : ${telegramEscape(event.action)}`,
    `<b>Caissier</b> : ${telegramEscape(event.cashier)}`,
    `<b>Heure</b> : ${telegramEscape(time)}`,
    "",
    `<b>Détails</b> : ${telegramEscape(event.details)}`
  ].join("\n");
}

function buildDailyTelegramReport() {
  const totalCA = dayRevenue();
  const wages = getTodayWages();
  const starting = getTodayStartingCash();
  const closing = getTodayClosingCash();
  const expected = starting + totalCA - wages;
  const discrepancy = closing - expected;
  const net = totalCA - wages;
  const ordersCount = data.orders.length;
  const itemsCount = dayItems();
  const sales = Object.values(getTodaySalesMap())
    .filter(item => item.qty > 0)
    .sort((a, b) => b.rev - a.rev)
    .slice(0, 5);

  const ingredients = loadIngredients();
  const audits = loadAudits();
  const dayAudit = audits[today] || {};
  const recipeSales = {};
  data.orders.forEach(o => {
    (o.items || []).forEach(item => {
      const recipe = RECIPES[item.name];
      if (!recipe) return;
      const q = +item.qty || 0;
      recipe.forEach(step => {
        recipeSales[step.ingredientId] = (recipeSales[step.ingredientId] || 0) + step.qty * q;
      });
    });
  });

  const stockIssues = ingredients.map(ing => {
    const sold = recipeSales[ing.id] || 0;
    const entry = dayAudit[ing.id];
    if (!entry) return null;
    const expectedIng = Math.max(0, entry.start - sold);
    const diff = entry.end - expectedIng;
    if (diff === 0) return null;
    return `${ing.name}: ${diff > 0 ? "+" : ""}${diff} ${ing.unit}`;
  }).filter(Boolean);

  const topSalesText = sales.length
    ? sales.map((item, index) => `${index + 1}. ${telegramEscape(item.name)} — ${item.qty} pcs / ${dt(item.rev)}`).join("\n")
    : "Aucune vente enregistrée.";

  const stockText = stockIssues.length
    ? stockIssues.map(item => `- ${telegramEscape(item)}`).join("\n")
    : "Aucun écart stock déclaré.";

  return [
    "<b>Zina Coffee | Rapport de clôture</b>",
    `<b>Date</b> : ${telegramEscape(today)}`,
    "",
    "<b>Résumé ventes</b>",
    `Commandes : ${ordersCount}`,
    `Articles : ${itemsCount}`,
    `Chiffre d'affaires : ${dt(totalCA)}`,
    `Bénéfice net : ${dt(net)}`,
    "",
    "<b>Caisse</b>",
    `Fonds départ : ${dt(starting)}`,
    `Salaires : ${dt(wages)}`,
    `Espèces réelles : ${dt(closing)}`,
    `Espèces attendues : ${dt(expected)}`,
    `Écart caisse : ${discrepancy >= 0 ? "+" : ""}${dt(discrepancy)}`,
    "",
    "<b>Top produits</b>",
    topSalesText,
    "",
    "<b>Stock</b>",
    stockText
  ].join("\n");
}

function loadAuditLogs() {
  try {
    return JSON.parse(localStorage.getItem(LOGS_KEY)) || [];
  } catch (e) {
    return [];
  }
}

function saveAuditLogs(logs) {
  try {
    localStorage.setItem(LOGS_KEY, JSON.stringify(logs.slice(0, 1000)));
  } catch (e) {}
}

function logAuditEvent(action, details) {
  const logs = loadAuditLogs();
  const event = {
    time: new Date().toISOString(),
    cashier: activeCashier ? activeCashier.name : (selectedCashier ? selectedCashier.name : "Système"),
    action,
    details
  };
  logs.unshift(event);
  saveAuditLogs(logs);
  
  if (activeAdminTab === "logs") {
    renderAuditLogs();
  }
  
  if (shouldNotifyTelegram(action)) {
    sendTelegramNotification(buildSecurityTelegramMessage(event));
  }
}

function renderAuditLogs() {
  const body = $("auditLogsTableBody");
  if (!body) return;
  const logs = loadAuditLogs();
  if (logs.length === 0) {
    body.innerHTML = `<tr><td colspan="4" style="text-align: center; padding: 24px; color: var(--muted); font-weight: 700;">Aucun log d'audit enregistré.</td></tr>`;
    return;
  }
  body.innerHTML = logs.map(l => {
    const t = new Date(l.time).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    let badgeColor = "var(--text)";
    let badgeBg = "var(--soft-2)";
    
    const act = String(l.action).toLowerCase();
    if (act.includes("échec") || act.includes("bloqué") || act.includes("suppression") || act.includes("vider") || act.includes("reset") || act.includes("fantôme") || act.includes("alarme")) {
      badgeColor = "var(--red)";
      badgeBg = "var(--red-bg)";
    } else if (act.includes("retour") || act.includes("annul")) {
      badgeColor = "#c97d02";
      badgeBg = "rgba(201, 125, 2, 0.1)";
    } else if (act.includes("connexion") || act.includes("encaissement")) {
      badgeColor = "var(--green)";
      badgeBg = "var(--green-bg)";
    }
    
    return `
      <tr style="border-bottom: 1px solid var(--line); font-weight: 700; vertical-align: middle;">
        <td style="padding: 10px 12px; color: var(--muted); font-size: 11px;">${t}</td>
        <td style="padding: 10px 12px; color: var(--text);">${escHtml(l.cashier)}</td>
        <td style="padding: 10px 12px;">
          <span style="display: inline-block; padding: 3px 8px; border-radius: 6px; font-size: 10px; text-transform: uppercase; background: ${badgeBg}; color: ${badgeColor};">${escHtml(l.action)}</span>
        </td>
        <td style="padding: 10px 12px; color: var(--muted); max-width: 320px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${escHtml(l.details)}">${escHtml(l.details)}</td>
      </tr>
    `;
  }).join("");
}

// Background Ghost Cart Protection (Auto-Timeout)
setInterval(() => {
  if (cart.length > 0 && Date.now() - lastCartActivity > 5 * 60 * 1000) {
    const total = cartTotal();
    const itemsText = cart.map(i => `${i.qty}x ${i.name}`).join(", ");
    cart = [];
    resetTicketMeta();
    $("paid").value = "";
    paidBuffer = "";
    renderCart();
    
    logAuditEvent("Panier Fantôme", `Panier de ${dt(total)} contenant [${itemsText}] a été vidé automatiquement après 5 min d'inactivité.`);
    showToast("Session de ticket expirée (inactivité)");
  }
}, 30000);

const $ = id => document.getElementById(id);
const data = loadData();

function localDateKey(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function escHtml(str) {
  return String(str || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function decodeHtmlEntities(str) {
  const el = document.createElement("textarea");
  let value = String(str || "");
  let previous;
  do {
    previous = value;
    el.innerHTML = value;
    value = el.value;
  } while (value !== previous && /&(?:amp|lt|gt|quot|#39);/i.test(value));
  return value;
}

function cleanStr(str) {
  return String(str || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function loadUiZoom() {
  try {
    return Math.min(1.25, Math.max(0.8, Number(localStorage.getItem(ZOOM_KEY)) || 1));
  } catch (e) {
    return 1;
  }
}

function applyUiZoom() {
  document.documentElement.style.setProperty("--ui-zoom", uiZoom);
  document.body.style.zoom = String(uiZoom);
  if ($("zoomResetBtn")) $("zoomResetBtn").textContent = `${Math.round(uiZoom * 100)}%`;
}

function setUiZoom(nextZoom) {
  uiZoom = Math.min(1.25, Math.max(0.8, Number(nextZoom) || 1));
  try {
    localStorage.setItem(ZOOM_KEY, String(uiZoom));
  } catch (e) {}
  applyUiZoom();
}

function zoomIn() {
  setUiZoom(uiZoom + 0.05);
}

function zoomOut() {
  setUiZoom(uiZoom - 0.05);
}

function resetZoom() {
  setUiZoom(1);
}

// 3D TAC-TACTILE Web Audio Synthesizer
let audioCtx = null;
try {
  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (AudioContextClass) {
    audioCtx = new AudioContextClass();
  }
} catch (e) {
  console.warn("Web Audio API not supported or blocked in this environment:", e);
}

function playTactileBeep(type = 'click') {
  if (!audioCtx) return;
  try {
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    
    const now = audioCtx.currentTime;
    
    if (type === 'click') {
      // Standard tactile wood-click: short sine sweep
      const osc = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(300, now + 0.02);
      
      gainNode.gain.setValueAtTime(0.04, now);
      gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.02);
      
      osc.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      
      osc.start(now);
      osc.stop(now + 0.02);
    } else if (type === 'success') {
      // Deluxe polyphonic major-third double-bell sweep
      const osc1 = audioCtx.createOscillator();
      const gain1 = audioCtx.createGain();
      osc1.type = 'triangle';
      osc1.frequency.setValueAtTime(523.25, now);
      gain1.gain.setValueAtTime(0.06, now);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      osc1.connect(gain1);
      gain1.connect(audioCtx.destination);
      osc1.start(now);
      osc1.stop(now + 0.25);
      
      setTimeout(() => {
        try {
          if (!audioCtx) return;
          const osc2 = audioCtx.createOscillator();
          const gain2 = audioCtx.createGain();
          osc2.type = 'sine';
          osc2.frequency.setValueAtTime(659.25, audioCtx.currentTime);
          gain2.gain.setValueAtTime(0.05, audioCtx.currentTime);
          gain2.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.22);
          osc2.connect(gain2);
          gain2.connect(audioCtx.destination);
          osc2.start();
          osc2.stop(audioCtx.currentTime + 0.22);
        } catch (e) {}
      }, 60);
    } else if (type === 'error') {
      // Pleasant retro analog sweep warning
      const osc = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(140, now);
      osc.frequency.linearRampToValueAtTime(60, now + 0.18);
      
      gainNode.gain.setValueAtTime(0.08, now);
      gainNode.gain.linearRampToValueAtTime(0.001, now + 0.18);
      
      const filter = audioCtx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(400, now);
      
      osc.connect(filter);
      filter.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      
      osc.start(now);
      osc.stop(now + 0.18);
    }
  } catch (e) {
    console.warn("Audio Context beep error:", e);
  }
}

function loadData() {
  try {
    const saved = JSON.parse(localStorage.getItem(KEY) || "null");
    if (saved && saved.date === today) {
      return {
        date: saved.date,
        sequence: saved.sequence || 1,
        orders: Array.isArray(saved.orders) ? saved.orders : []
      };
    }
  } catch (error) {
    console.warn("Could not load saved Menux data.", error);
  }
  return { date: today, sequence: 1, orders: [] };
}

function saveData() {
  localStorage.setItem(KEY, JSON.stringify(data));
  const archive = loadSalesArchive();
  archive[data.date] = data.orders;
  localStorage.setItem(ARCHIVE_KEY, JSON.stringify(archive));
}

function loadSalesArchive() {
  try {
    const archive = JSON.parse(localStorage.getItem(ARCHIVE_KEY) || "null");
    if (archive && typeof archive === "object" && !Array.isArray(archive)) return archive;
  } catch (error) {
    console.warn("Could not load saved Menux sales archive.", error);
  }
  return {};
}

function loadCashiers() {
  try {
    let list = JSON.parse(localStorage.getItem(CASHIER_KEY)) || [];
    if (!Array.isArray(list)) list = [];
    if (!list.some(c => c.name.toLowerCase() === "admin")) {
      list.unshift({ id: "c_super_admin", name: "admin", pin: "0852", isSuperAdmin: true });
      localStorage.setItem(CASHIER_KEY, JSON.stringify(list));
    }
    return list;
  } catch (error) {
    return [{ id: "c_super_admin", name: "admin", pin: "0852", isSuperAdmin: true }];
  }
}

function saveCashiersList() {
  localStorage.setItem(CASHIER_KEY, JSON.stringify(cashiers));
}

function isOwnerPin(pin) {
  return pin === MASTER_PIN || pin === "0852";
}

function isActiveSuperAdmin() {
  return Boolean(activeCashier && (activeCashier.isSuperAdmin || activeCashier.name.toLowerCase() === "admin"));
}

function normalizeProduct(product, index = 0) {
  return {
    id: product.id || "m" + index,
    category: decodeHtmlEntities(product.category || "Menu").trim() || "Menu",
    name: decodeHtmlEntities(product.name || "Article").trim() || "Article",
    price: Math.max(0, Number(product.price) || 0),
    stock: product.stock === null || product.stock === "" || product.stock === undefined ? null : Math.max(0, Number(product.stock) || 0),
    lowStock: Math.max(1, Number(product.lowStock) || 5),
    active: product.active !== false
  };
}

function loadCatalog() {
  try {
    const saved = JSON.parse(localStorage.getItem(CATALOG_KEY) || "null");
    if (Array.isArray(saved) && saved.length) {
      return saved.map(normalizeProduct);
    }
  } catch (error) {
    console.warn("Could not load saved Menux catalog.", error);
  }
  return DEFAULT_MENU.map(normalizeProduct);
}

function saveCatalog() {
  localStorage.setItem(CATALOG_KEY, JSON.stringify(menu));
  recordStockSnapshot(today);
}

function loadIngredients() {
  try {
    const saved = JSON.parse(localStorage.getItem(INGREDIENTS_KEY) || "null");
    if (Array.isArray(saved) && saved.length) return saved;
  } catch (e) {}
  return DEFAULT_INGREDIENTS;
}

function saveIngredients(list) {
  localStorage.setItem(INGREDIENTS_KEY, JSON.stringify(list));
}

function deductIngredientsForCart(cartItems) {
  const ingredients = loadIngredients();
  cartItems.forEach(cartItem => {
    const recipe = RECIPES[cartItem.name];
    if (!recipe) return;
    recipe.forEach(recipeStep => {
      const ing = ingredients.find(i => i.id === recipeStep.ingredientId);
      if (ing) {
        const totalDeduction = recipeStep.qty * cartItem.qty;
        ing.stock = Math.max(0, ing.stock - totalDeduction);
      }
    });
  });
  saveIngredients(ingredients);
}

function loadStockLog() {
  try {
    const saved = JSON.parse(localStorage.getItem(STOCK_KEY) || "null");
    if (saved && typeof saved === "object") {
      return {
        snapshots: saved.snapshots || {},
        events: Array.isArray(saved.events) ? saved.events : []
      };
    }
  } catch (error) {
    console.warn("Could not load saved Menux stock log.", error);
  }
  return { snapshots: {}, events: [] };
}

function saveStockLog(log) {
  localStorage.setItem(STOCK_KEY, JSON.stringify(log));
}

function stockSnapshotFromCatalog() {
  return menu.map(item => ({
    id: item.id,
    category: item.category,
    name: item.name,
    stock: item.stock,
    price: item.price
  }));
}

function recordStockSnapshot(dateKey = today) {
  const log = loadStockLog();
  log.snapshots[dateKey] = {
    savedAt: new Date().toISOString(),
    items: stockSnapshotFromCatalog()
  };
  saveStockLog(log);
}

function appendStockEvent(event) {
  const log = loadStockLog();
  log.events.push({ ...event, createdAt: new Date().toISOString() });
  log.events = log.events.slice(-1000);
  log.snapshots[today] = {
    savedAt: new Date().toISOString(),
    items: stockSnapshotFromCatalog()
  };
  saveStockLog(log);
}

function dt(n) {
  const value = Math.round((Number(n) || 0) * 100) / 100;
  return `${value.toLocaleString("fr-FR", { maximumFractionDigits: 2 })} DT`;
}

// Dynamic shift calculation (Morning Jour vs Evening Nuit)
function getShift(timeStr) {
  if (!timeStr) return "Jour";
  const [h, m] = timeStr.split(":").map(Number);
  const totalMinutes = h * 60 + m;
  const jourStart = 6 * 60; // 06:00
  const jourEnd = 14 * 60 + 30; // 14:30
  if (totalMinutes >= jourStart && totalMinutes < jourEnd) {
    return "Jour";
  } else {
    return "Nuit";
  }
}

function ticketCode() {
  return `#${String(data.sequence).padStart(3, "0")}`;
}

function cartSubtotal() {
  return cart.reduce((sum, item) => sum + item.price * item.qty, 0);
}

function getDiscountValue() {
  return 0;
}

function getDiscountType() {
  return "amount";
}

function cartDiscount() {
  const subtotal = cartSubtotal();
  const value = getDiscountValue();
  if (value <= 0 || subtotal <= 0) return 0;
  const discount = getDiscountType() === "percent" ? subtotal * Math.min(value, 100) / 100 : value;
  return Math.min(subtotal, Math.round(discount * 100) / 100);
}

function cartTotal() {
  return Math.max(0, cartSubtotal() - cartDiscount());
}

// Dynamic suggestion chips based on active net total
function calculateCashSuggestions(total) {
  if (total <= 0) return [5, 10, 20, 50];
  
  const exact = Number(total.toFixed(2));
  const list = new Set();
  
  // Auto-suggest closest standard bills
  const standardBills = [5, 10, 20, 30, 40, 50, 100];
  
  standardBills.forEach(bill => {
    if (bill > exact) {
      list.add(bill);
    }
  });
  
  // Also add exact total, next highest integer
  const nextInt = Math.ceil(exact);
  if (nextInt > exact && nextInt < exact + 5) {
    list.add(nextInt);
  }
  
  // Turn back into sorted array, select closest 4 values + exact
  const suggestions = Array.from(list).sort((a, b) => a - b).slice(0, 4);
  return [exact, ...suggestions];
}

function renderCashSuggestions() {
  const grid = $("suggestionChipsGrid");
  if (!grid) return;

  const total = cartTotal();
  const chips = calculateCashSuggestions(total);

  grid.innerHTML = chips.map((val, idx) => {
    const isExact = idx === 0;
    const text = isExact ? "Exact" : `${val} DT`;
    return `
      <button class="pay-chip" data-pay="${val}">${text}</button>
    `;
  }).join("");

  // Re-bind events to custom chips
  grid.querySelectorAll("[data-pay]").forEach(btn => {
    btn.onclick = () => {
      playTactileBeep('click');
      const value = btn.dataset.pay;
      $("paid").value = Number(value).toFixed(2);
      renderCart();
    };
  });
}

function cartCount() {
  return cart.reduce((sum, item) => sum + item.qty, 0);
}

// Global day revenue statistics
function dayRevenue() {
  return data.orders.reduce((sum, order) => sum + order.total, 0);
}

function shiftJourRevenue() {
  return data.orders
    .filter(o => getShift(o.time) === "Jour")
    .reduce((sum, o) => sum + o.total, 0);
}

function shiftNuitRevenue() {
  return data.orders
    .filter(o => getShift(o.time) === "Nuit")
    .reduce((sum, o) => sum + o.total, 0);
}

function dayItems() {
  return data.orders.reduce((sum, order) => {
    return sum + order.items.reduce((innerSum, item) => innerSum + item.qty, 0);
  }, 0);
}

function csvEscape(value) {
  return `"${String(value).replaceAll('"', '""')}"`;
}

function showToast(text) {
  const toast = $("toast");
  toast.textContent = text;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 1000);
}

function updateClock() {
  const clockText = new Date().toLocaleTimeString("fr-FR", {
    hour: "2-digit",
    minute: "2-digit"
  });
  $("clock").textContent = clockText;
}

// === VIRTUAL NUMPAD FOR PAID INPUT ===
function showPaidNumpad() {
  const np = $("paidNumpad");
  if (!np) return;
  np.style.display = "block";
  paidBuffer = ($("paid").value || "").trim();
}

function numpadDigit(d) {
  playTactileBeep('click');
  if (d === '.' && paidBuffer.includes('.')) return;
  paidBuffer += d;
  $("paid").value = paidBuffer;
  renderCart();
}

function numpadBack() {
  playTactileBeep('click');
  paidBuffer = paidBuffer.slice(0, -1);
  $("paid").value = paidBuffer;
  renderCart();
}

function numpadClearPaid() {
  playTactileBeep('click');
  paidBuffer = "";
  $("paid").value = "";
  renderCart();
}

function numpadDone() {
  playTactileBeep('success');
  $("paidNumpad").style.display = "none";
}

function numpadExact() {
  playTactileBeep('click');
  $("paid").value = cartTotal().toFixed(2);
  paidBuffer = $("paid").value;
  $("paidNumpad").style.display = "none";
  renderCart();
}

// PREMIUM CUSTOM PROMISE-BASED OVERLAYS
function showCustomConfirm(message) {
  playTactileBeep('click');
  return new Promise((resolve) => {
    $("dialog-title").textContent = "Confirmation";
    $("dialog-body").innerHTML = `<p style="font-weight: 800; text-align: center; margin: 8px 0; font-size: 15px; line-height: 1.4;">${message}</p>`;
    $("dialog-footer").innerHTML = `
      <button class="small-btn" id="dialog-cancel-btn" style="padding: 10px 16px; border-radius: 12px; font-weight: 900;"><i data-lucide="x"></i> Annuler</button>
      <button class="small-btn" id="dialog-ok-btn" style="background: var(--text); color: var(--card); border: 0; padding: 10px 16px; border-radius: 12px; font-weight: 900;"><i data-lucide="check"></i> Confirmer</button>
    `;
    lucide.createIcons();
    openModal("custom-dialog");

    $("dialog-cancel-btn").onclick = () => {
      playTactileBeep('click');
      closeModal("custom-dialog");
      resolve(false);
    };
    $("dialog-ok-btn").onclick = () => {
      playTactileBeep('success');
      closeModal("custom-dialog");
      resolve(true);
    };
    $("dialog-close-x").onclick = () => {
      playTactileBeep('click');
      closeModal("custom-dialog");
      resolve(false);
    };
  });
}

function showCustomPrompt(message, type = "text", placeholder = "") {
  playTactileBeep('click');
  return new Promise((resolve) => {
    $("dialog-title").textContent = "Saisie Requise";
    $("dialog-body").innerHTML = `
      <p style="font-weight: 800; margin: 0 0 12px; font-size: 14px;">${message}</p>
      <input id="dialog-input-field" type="${type}" placeholder="${placeholder}" autocomplete="off" style="width: 100%; border: 1px solid var(--line); border-radius: 13px; padding: 12px; font-weight: 800; outline: none; background: var(--card); color: var(--text);" />
    `;
    $("dialog-footer").innerHTML = `
      <button class="small-btn" id="dialog-prompt-cancel" style="padding: 10px 16px; border-radius: 12px; font-weight: 900;"><i data-lucide="x"></i> Annuler</button>
      <button class="small-btn" id="dialog-prompt-ok" style="background: var(--text); color: var(--card); border: 0; padding: 10px 16px; border-radius: 12px; font-weight: 900;"><i data-lucide="check"></i> Valider</button>
    `;
    lucide.createIcons();
    
    openModal("custom-dialog");
    const input = $("dialog-input-field");
    input.focus();

    input.onkeydown = (e) => {
      if (e.key === "Enter") {
        playTactileBeep('success');
        closeModal("custom-dialog");
        resolve(input.value);
      }
    };

    $("dialog-prompt-cancel").onclick = () => {
      playTactileBeep('click');
      closeModal("custom-dialog");
      resolve(null);
    };
    $("dialog-prompt-ok").onclick = () => {
      playTactileBeep('success');
      closeModal("custom-dialog");
      resolve(input.value);
    };
    $("dialog-close-x").onclick = () => {
      playTactileBeep('click');
      closeModal("custom-dialog");
      resolve(null);
    };
  });
}

function showCustomPinPrompt(message) {
  playTactileBeep('click');
  return new Promise((resolve) => {
    const now = Date.now();
    if (lockoutUntil && now < lockoutUntil) {
      const secondsLeft = Math.ceil((lockoutUntil - now) / 1000);
      if (secondsLeft < 60) {
        showToast(`Bloqué! Attendez ${secondsLeft}s`);
      } else {
        const minutesLeft = Math.ceil(secondsLeft / 60);
        showToast(`Bloqué! Attendez ${minutesLeft} min`);
      }
      playTactileBeep('error');
      resolve(null);
      return;
    }

    $("dialog-title").textContent = "Sécurité Caisse";
    let enteredPin = "";
    
    $("dialog-body").innerHTML = `
      <p style="font-weight: 800; margin: 0 0 12px; font-size: 14px; text-align: center;">${message}</p>
      <div class="pin-display-dots" id="dialogPinDots" style="justify-content: center; margin: 12px 0;">
        <div class="pin-display-dot"></div>
        <div class="pin-display-dot"></div>
        <div class="pin-display-dot"></div>
        <div class="pin-display-dot"></div>
      </div>
      <div class="pin-numpad" style="margin-top: 12px;">
        <button class="numpad-btn" id="d-btn-1">1</button>
        <button class="numpad-btn" id="d-btn-2">2</button>
        <button class="numpad-btn" id="d-btn-3">3</button>
        <button class="numpad-btn" id="d-btn-4">4</button>
        <button class="numpad-btn" id="d-btn-5">5</button>
        <button class="numpad-btn" id="d-btn-6">6</button>
        <button class="numpad-btn" id="d-btn-7">7</button>
        <button class="numpad-btn" id="d-btn-8">8</button>
        <button class="numpad-btn" id="d-btn-9">9</button>
        <button class="numpad-btn text-btn" id="d-btn-clear">Vider</button>
        <button class="numpad-btn" id="d-btn-0">0</button>
        <button class="numpad-btn text-btn" id="d-btn-del"><i data-lucide="delete"></i></button>
      </div>
    `;
    
    $("dialog-footer").innerHTML = `
      <button class="small-btn" id="dialogPinCancel" style="width: 100%; padding: 10px; border-radius: 12px; font-weight: 900; justify-content: center;"><i data-lucide="x"></i> Annuler</button>
    `;
    lucide.createIcons();
    
    openModal("custom-dialog");
    
    function updateDialogDots() {
      const dots = $("dialogPinDots").children;
      for (let i = 0; i < 4; i++) {
        if (i < enteredPin.length) {
          dots[i].classList.add("active");
        } else {
          dots[i].classList.remove("active");
        }
      }
    }
    
    function appendDigit(digit) {
      const tNow = Date.now();
      if (lockoutUntil && tNow < lockoutUntil) {
        const secondsLeft = Math.ceil((lockoutUntil - tNow) / 1000);
        if (secondsLeft < 60) {
          showToast(`Bloqué! Attendez ${secondsLeft}s`);
        } else {
          const minutesLeft = Math.ceil(secondsLeft / 60);
          showToast(`Bloqué! Attendez ${minutesLeft} min`);
        }
        playTactileBeep('error');
        closeModal("custom-dialog");
        resolve(null);
        return;
      }
      playTactileBeep('click');
      if (enteredPin.length < 4) {
        enteredPin += digit;
        updateDialogDots();
        if (enteredPin.length === 4) {
          setTimeout(() => {
            playTactileBeep('success');
            closeModal("custom-dialog");
            resolve(enteredPin);
          }, 150);
        }
      }
    }
    
    for (let i = 0; i <= 9; i++) {
      $(`d-btn-${i}`).onclick = () => appendDigit(i);
    }
    $("d-btn-clear").onclick = () => {
      playTactileBeep('click');
      enteredPin = "";
      updateDialogDots();
    };
    $("d-btn-del").onclick = () => {
      playTactileBeep('click');
      enteredPin = enteredPin.slice(0, -1);
      updateDialogDots();
    };
    
    $("dialogPinCancel").onclick = () => {
      playTactileBeep('click');
      closeModal("custom-dialog");
      resolve(null);
    };
    $("dialog-close-x").onclick = () => {
      playTactileBeep('click');
      closeModal("custom-dialog");
      resolve(null);
    };
  });
}

// THEME TRANSITIONS (Mirror swipe animation)
function switchTheme() {
  playTactileBeep('click');
  const swipe = $("theme-swipe");
  swipe.style.opacity = "1";
  
  setTimeout(() => {
    document.documentElement.classList.toggle("dark");
    const isDark = document.documentElement.classList.contains("dark");
    localStorage.setItem("menux_prestige_theme", isDark ? "dark" : "light");
    
    setTimeout(() => {
      swipe.style.opacity = "0";
    }, 150);
  }, 300);
}

function initTheme() {
  const savedTheme = localStorage.getItem("menux_prestige_theme");
  if (savedTheme === "dark") {
    document.documentElement.classList.add("dark");
  } else {
    document.documentElement.classList.remove("dark");
  }
}

function captureTicketMeta() {
  return {
    orderMode: currentOrderMode,
    discountValue: getDiscountValue(),
    discountType: getDiscountType()
  };
}

function applyTicketMeta(meta = {}) {
  currentOrderMode = meta.orderMode || "Sur place";
}

function resetTicketMeta() {
  currentOrderMode = "Sur place";
}

// MULTI-TICKET HOLDS & DRAFTS TRAY (UX Breakthrough)
function renderHoldsTray() {
  const tray = $("holdTicketsBar");
  if (!tray) return;

  if (holds.length === 0) {
    tray.innerHTML = `<span style="font-size: 11px; color: var(--muted); font-weight: 700; padding: 4px 6px;">Aucun brouillon en attente</span>`;
    return;
  }

  tray.innerHTML = holds.map((h, idx) => `
    <div class="hold-chip" onclick="resumeHeldTicket('${h.id}')">
      <i data-lucide="pin" style="width:12px; height:12px;"></i> Brouillon ${h.sequence} (${h.time})
      <span style="color: var(--red); font-weight: 900; margin-left: 4px;" onclick="event.stopPropagation(); releaseHeldTicket('${h.id}')">×</span>
    </div>
  `).join("");
  lucide.createIcons();
}

function holdCurrentTicket() {
  if (cart.length === 0) {
    showToast("Panier vide");
    return;
  }

  playTactileBeep('success');
  const now = new Date();
  const holdItem = {
    id: "h_" + Date.now(),
    time: now.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }),
    sequence: holds.length + 1,
    cart: [...cart],
    meta: captureTicketMeta()
  };

  holds.push(holdItem);
  cart = [];
  resetTicketMeta();
  $("paid").value = "";
  renderCart();
  renderHoldsTray();
  showToast("Ticket mis en attente");
}

function resumeHeldTicket(id) {
  playTactileBeep('success');
  const found = holds.find(h => h.id === id);
  if (!found) return;

  // Swap active cart with held cart
  const temp = [...cart];
  const tempMeta = captureTicketMeta();
  cart = [...found.cart];
  applyTicketMeta(found.meta);

  if (temp.length > 0) {
    found.cart = [...temp];
    found.meta = tempMeta;
  } else {
    holds = holds.filter(h => h.id !== id);
  }

  renderCart();
  renderHoldsTray();
  showToast("Brouillon restauré");
}

function releaseHeldTicket(id) {
  playTactileBeep('click');
  holds = holds.filter(h => h.id !== id);
  renderHoldsTray();
  showToast("Brouillon supprimé");
}

// CASHIER ACCESS PORTAL
function renderCashierPortal() {
  const container = $("profiles-list-container");
  
  if (cashiers.length === 0) {
    container.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 24px; background: var(--soft-2); border: 2px dashed var(--line); border-radius: 18px; font-weight: 800; color: var(--muted);">
        Aucun compte caissier. Veuillez initialiser la caisse en ajoutant le premier profil.
      </div>
    `;
    $("createFirstCashierBtn").style.display = "block";
    lucide.createIcons();
    return;
  }

  $("createFirstCashierBtn").style.display = "block";

  const presetColors = [
    "var(--accent)", 
    "var(--accent-2)", 
    "var(--text)", 
    "var(--muted)", 
    "#2f9b5f", 
    "#c94d42"
  ];

  container.innerHTML = cashiers.map((c, idx) => {
    const color = presetColors[idx % presetColors.length];
    const initial = c.name.charAt(0).toUpperCase();
    const isAdmin = c.isSuperAdmin || c.name.toLowerCase() === "admin";
    return `
      <div class="cashier-profile-btn" onclick="selectCashierProfile('${c.id}')">
        <button class="delete-profile-badge" onclick="event.stopPropagation(); triggerDeleteCashier('${c.id}')">×</button>
        <div class="avatar-circle" style="background: ${color}; box-shadow: 0 8px 16px rgba(0,0,0,0.06); font-family: var(--font-display);">${initial}</div>
        <span class="profile-name">${escHtml(c.name)}</span>
        <span class="profile-role">${isAdmin ? "Admin" : "Cashier"}</span>
      </div>
    `;
  }).join("");
  lucide.createIcons();
}

function selectCashierProfile(id) {
  playTactileBeep('click');
  selectedCashier = cashiers.find(c => c.id === id);
  if (!selectedCashier) return;
  
  typedPin = "";
  updatePinDots();
  
  $("pin-greeting").textContent = `Bienvenue, ${selectedCashier.name}`;
  $("pin-avatar").textContent = selectedCashier.name.charAt(0).toUpperCase();
  
  const presetColors = ["var(--accent)", "var(--accent-2)", "var(--text)", "var(--muted)", "#2f9b5f", "#c94d42"];
  const index = cashiers.findIndex(c => c.id === id);
  $("pin-avatar").style.background = presetColors[index % presetColors.length];

  $("profile-selector-view").style.display = "none";
  $("pin-pad-view").style.display = "block";
  lucide.createIcons();
}

function backToProfiles() {
  playTactileBeep('click');
  selectedCashier = null;
  typedPin = "";
  $("pin-pad-view").style.display = "none";
  $("profile-selector-view").style.display = "block";
  lucide.createIcons();
}

function typePinDigit(digit) {
  const now = Date.now();
  if (lockoutUntil && now < lockoutUntil) {
    const secondsLeft = Math.ceil((lockoutUntil - now) / 1000);
    if (secondsLeft < 60) {
      showToast(`Bloqué! Attendez ${secondsLeft}s`);
    } else {
      const minutesLeft = Math.ceil(secondsLeft / 60);
      showToast(`Bloqué! Attendez ${minutesLeft} min`);
    }
    playTactileBeep('error');
    return;
  }
  playTactileBeep('click');
  if (typedPin.length < 4) {
    typedPin += digit;
    updatePinDots();

    if (typedPin.length === 4) {
      verifyCashierPin();
    }
  }
}

function deletePinDigit() {
  playTactileBeep('click');
  if (typedPin.length > 0) {
    typedPin = typedPin.slice(0, -1);
    updatePinDots();
  }
}

function clearPinInput() {
  playTactileBeep('click');
  typedPin = "";
  updatePinDots();
}

function updatePinDots() {
  const dotsRow = $("pinDotsRow");
  const dots = dotsRow.children;
  for (let i = 0; i < 4; i++) {
    if (i < typedPin.length) {
      dots[i].classList.add("active");
    } else {
      dots[i].classList.remove("active");
    }
  }
}

function verifyCashierPin() {
  const now = Date.now();
  if (lockoutUntil && now < lockoutUntil) {
    const secondsLeft = Math.ceil((lockoutUntil - now) / 1000);
    if (secondsLeft < 60) {
      showToast(`Bloqué! Attendez ${secondsLeft}s`);
    } else {
      const minutesLeft = Math.ceil(secondsLeft / 60);
      showToast(`Bloqué! Attendez ${minutesLeft} min`);
    }
    playTactileBeep('error');
    typedPin = "";
    updatePinDots();
    return;
  }

  setTimeout(() => {
    if (typedPin === selectedCashier.pin) {
      playTactileBeep('success');
      activeCashier = selectedCashier;
      $("activeCashierName").textContent = activeCashier.name;
      
      showToast(`Bonjour ${activeCashier.name}`);
      logAuditEvent("Connexion", `Authentification réussie.`);
      
      $("portal-container").style.display = "none";
      $("app-container").style.display = "block";
      
      typedPin = "";
      updatePinDots();
      failedPinAttempts = 0; // Reset on success
      saveLockoutCount(0); // Reset lockout count on successful entry
      renderAll();
    } else {
      playTactileBeep('error');
      failedPinAttempts++;
      const card = $("pin-pad-view");
      card.classList.add("shake-anim");
      
      logAuditEvent("Échec PIN", `Tentative d'accès refusée avec PIN incorrect sur le profil ${selectedCashier.name} (${failedPinAttempts}/3).`);
      
      if (failedPinAttempts >= 3) {
        triggerNewLockout();
      } else {
        showToast(`PIN Incorrect (${3 - failedPinAttempts} restants)`);
      }
      
      setTimeout(() => {
        card.classList.remove("shake-anim");
        typedPin = "";
        updatePinDots();
      }, 350);
    }
  }, 150);
}

function lockPOS() {
  playTactileBeep('click');
  logAuditEvent("Déconnexion", `Session caissier verrouillée.`);
  activeCashier = null;
  $("app-container").style.display = "none";
  $("portal-container").style.display = "flex";
  $("pin-pad-view").style.display = "none";
  $("profile-selector-view").style.display = "block";
  renderCashierPortal();
}

function triggerCreateCashier() {
  showCustomPinPrompt("Admin PIN :").then(caissePin => {
    if (caissePin === null) return;
    if (!isOwnerPin(caissePin)) {
      playTactileBeep('error');
      failedPinAttempts++;
      if (failedPinAttempts >= 3) {
        triggerNewLockout();
      } else {
        showToast(`PIN incorrect (${3 - failedPinAttempts} restants)`);
      }
      return;
    }
    failedPinAttempts = 0; // Reset on success
    saveLockoutCount(0); // Reset lockout count on successful entry

    showCustomPrompt("Nom du nouveau caissier :", "text", "Saisir un nom...").then(name => {
      if (name === null) return;
      name = name.trim();
      if (!name) {
        showToast("Nom invalide");
        return;
      }

      showCustomPrompt(`Code PIN pour ${escHtml(name)} (4 chiffres) :`, "password", "Saisir PIN...").then(pin => {
        if (pin === null) return;
        if (!pin || pin.length !== 4 || isNaN(pin)) {
          showToast("Le PIN doit contenir exactement 4 chiffres");
          return;
        }

        const newId = "c_" + Date.now();
        cashiers.push({ id: newId, name, pin });
        saveCashiersList();
        renderCashierPortal();
        renderSettingsCashiers();
        showToast("Caissier créé");
        logAuditEvent("Création Caissier", `Caissier nommé "${name}" créé.`);
      });
    });
  });
}

function triggerDeleteCashier(id) {
  const target = cashiers.find(c => c.id === id);
  if (target && target.name.toLowerCase() === "admin") {
    showToast("Impossible de supprimer le Super Admin!");
    playTactileBeep('error');
    return;
  }

  showCustomPinPrompt("Admin PIN :").then(caissePin => {
    if (caissePin === null) return;
    if (!isOwnerPin(caissePin)) {
      playTactileBeep('error');
      failedPinAttempts++;
      if (failedPinAttempts >= 3) {
        triggerNewLockout();
      } else {
        showToast(`PIN incorrect (${3 - failedPinAttempts} restants)`);
      }
      return;
    }
    failedPinAttempts = 0; // Reset on success
    saveLockoutCount(0); // Reset lockout count on successful entry

    cashiers = cashiers.filter(c => c.id !== id);
    saveCashiersList();
    renderCashierPortal();
    renderSettingsCashiers();
    showToast("Caissier supprimé");
    logAuditEvent("Suppression Caissier", `Caissier nommé "${target.name}" supprimé.`);
  });
}

// MODALS
function openModal(id) {
  $(id).classList.add("active");
  if (id === "settings-modal") {
    switchAdminTab(activeAdminTab || "recette");
  }
}

function closeModal(id) {
  $(id).classList.remove("active");
}

let activeAdminTab = "recette";
const ADMIN_TAB_HELP = {
  recette: ["Dashboard", "Today's sales, cash drawer, wages, and quick reports."],
  produits: ["Products", "Add menu items and adjust stock counts."],
  systeme: ["Team", "Add cashiers, export reports, reset the day, and reprint sales."],
  audit: ["Stock Check", "Compare opening stock, sold ingredients, and closing stock."],
  logs: ["Activity Log", "Security history for logins, deletes, resets, and changes."]
};

function switchAdminTab(tabName) {
  playTactileBeep('click');
  activeAdminTab = tabName;
  document.querySelectorAll(".admin-tab-btn").forEach(btn => {
    btn.classList.toggle("active", btn.id === `btn-tab-${tabName}`);
  });
  document.querySelectorAll(".admin-tab-content").forEach(content => {
    content.style.display = content.id === `admin-tab-${tabName}` ? "block" : "none";
  });
  const help = ADMIN_TAB_HELP[tabName] || ADMIN_TAB_HELP.recette;
  if ($("admin-helper-title")) $("admin-helper-title").textContent = help[0];
  if ($("admin-helper-text")) $("admin-helper-text").textContent = help[1];
  renderAdminPanel();
}
window.switchAdminTab = switchAdminTab;

function getTodaySalesMap() {
  const sales = {};
  data.orders.forEach(o => {
    (o.items || []).forEach(item => {
      const k = item.name;
      if (!sales[k]) sales[k] = { name: item.name, qty: 0, rev: 0 };
      const q = +item.qty || 0;
      const r = (+item.price || 0) * q;
      sales[k].qty += q;
      sales[k].rev += r;
    });
  });
  return sales;
}

const WAGES_KEY = "menux_caisse_daily_wages_v1";

function loadWages() {
  try {
    return JSON.parse(localStorage.getItem(WAGES_KEY) || "null") || {};
  } catch (e) {
    return {};
  }
}

function saveWages(wages) {
  localStorage.setItem(WAGES_KEY, JSON.stringify(wages));
}

function getTodayWages() {
  const wages = loadWages();
  return wages[today] || 0;
}

function loadStartingCash() {
  try {
    return JSON.parse(localStorage.getItem(STARTING_CASH_KEY) || "null") || {};
  } catch (e) {
    return {};
  }
}

function saveStartingCash(cash) {
  localStorage.setItem(STARTING_CASH_KEY, JSON.stringify(cash));
}

function getTodayStartingCash() {
  return loadStartingCash()[today] || 0;
}

function loadClosingCash() {
  try {
    return JSON.parse(localStorage.getItem(CLOSING_CASH_KEY) || "null") || {};
  } catch (e) {
    return {};
  }
}

function saveClosingCash(cash) {
  localStorage.setItem(CLOSING_CASH_KEY, JSON.stringify(cash));
}

function getTodayClosingCash() {
  return loadClosingCash()[today] || 0;
}

function updateStartingCash(val) {
  const num = Math.max(0, parseFloat(val) || 0);
  const cash = loadStartingCash();
  cash[today] = num;
  saveStartingCash(cash);
  logAuditEvent("Ajustement Fonds Caisse", `Fonds de caisse de départ modifié à ${dt(num)}.`);
  recalculateCashDrawer();
}
window.updateStartingCash = updateStartingCash;

function updateClosingCash(val) {
  const num = Math.max(0, parseFloat(val) || 0);
  const cash = loadClosingCash();
  cash[today] = num;
  saveClosingCash(cash);
  logAuditEvent("Ajustement Espèces Clôture", `Espèces réelles déclarées à la clôture: ${dt(num)}.`);
  recalculateCashDrawer();
}
window.updateClosingCash = updateClosingCash;

function recalculateCashDrawer() {
  const totalCA = dayRevenue();
  const wages = getTodayWages();
  const starting = getTodayStartingCash();
  const closing = getTodayClosingCash();
  
  const expected = starting + totalCA - wages;
  const discrepancy = closing - expected;
  
  const netRevenue = Math.max(0, totalCA - wages);
  
  if ($("expectedCashDisplay")) $("expectedCashDisplay").textContent = `Attendu: ${dt(expected)}`;
  if ($("netRevenueDisplay")) $("netRevenueDisplay").textContent = dt(netRevenue);
  
  const disp = $("cashDiscrepancyDisplay");
  if (disp) {
    disp.textContent = dt(discrepancy);
    if (discrepancy === 0) {
      disp.style.color = "var(--green)";
    } else if (discrepancy > 0) {
      disp.style.color = "var(--green)";
    } else {
      disp.style.color = "var(--red)";
      // Log critical discrepancy warning if massive
      if (Math.abs(discrepancy) >= 5) {
        logAuditEvent("Alarme Écart Caisse", `Négatif suspect détecté : ${dt(discrepancy)} de moins que prévu.`);
      }
    }
  }
}

function updateWagesValue(val) {
  const num = Math.max(0, parseFloat(val) || 0);
  const wages = loadWages();
  wages[today] = num;
  saveWages(wages);
  logAuditEvent("Mise à jour Salaires", `Salaires du jour modifiés à ${dt(num)}.`);
  recalculateCashDrawer();
}
window.updateWagesValue = updateWagesValue;

function renderRecetteTab() {
  const sales = getTodaySalesMap();
  const container = $("recetteListGrid");
  if (!container) return;

  const items = Object.values(sales).filter(s => s.qty > 0);
  if (items.length === 0) {
    container.innerHTML = `<span style="font-size: 12px; color: var(--muted); text-align: center; display: block; padding: 12px;">Aucune vente enregistrée pour ce shift.</span>`;
  } else {
    container.innerHTML = items.map(item => `
      <div class="recette-row">
        <span>${escHtml(item.name)} <strong style="color: var(--muted); font-size: 11px; margin-left: 4px;">× ${item.qty}</strong></span>
        <span>${dt(item.rev)}</span>
      </div>
    `).join("");
  }

  // Populate wages and starting/closing cash
  if ($("wagesInput")) $("wagesInput").value = getTodayWages();
  if ($("startingCashInput")) $("startingCashInput").value = getTodayStartingCash();
  if ($("closingCashInput")) $("closingCashInput").value = getTodayClosingCash();
  
  recalculateCashDrawer();
}

const AUDIT_KEY = "menux_caisse_ingredients_audits_v1";

function loadAudits() {
  try {
    return JSON.parse(localStorage.getItem(AUDIT_KEY) || "null") || {};
  } catch (e) {
    return {};
  }
}

function saveAudits(audits) {
  localStorage.setItem(AUDIT_KEY, JSON.stringify(audits));
}

function updateShiftAudit(ingId, field, val) {
  const num = Math.max(0, parseFloat(val) || 0);
  const audits = loadAudits();
  const ingredients = loadIngredients();
  const ing = ingredients.find(i => i.id === ingId);
  const name = ing ? ing.name : ingId;
  
  if (!audits[today]) audits[today] = {};
  if (!audits[today][ingId]) {
    audits[today][ingId] = { start: ing ? ing.stock : 0, end: ing ? ing.stock : 0 };
  }
  audits[today][ingId][field] = num;
  saveAudits(audits);

  logAuditEvent("Ajustement Inventaire", `Ingrédient [${name}] modifié (${field === "start" ? "Début 4 AM" : "Fin 2 PM"}: ${num} ${ing ? ing.unit : ""})`);

  if (field === "end") {
    if (ing) {
      ing.stock = num;
      saveIngredients(ingredients);
    }
  }
  renderAdminPanel();
}
window.updateShiftAudit = updateShiftAudit;

function renderAuditTab() {
  const ingredients = loadIngredients();
  const audits = loadAudits();
  const dayAudit = audits[today] || {};

  // Compute sales ingredients consumption map
  const recipeSales = {};
  data.orders.forEach(o => {
    (o.items || []).forEach(item => {
      const recipe = RECIPES[item.name];
      if (!recipe) return;
      const q = +item.qty || 0;
      recipe.forEach(step => {
        if (!recipeSales[step.ingredientId]) recipeSales[step.ingredientId] = 0;
        recipeSales[step.ingredientId] += step.qty * q;
      });
    });
  });

  const container = $("adminAuditGrid");
  if (!container) return;

  container.innerHTML = ingredients.map(ing => {
    const sold = recipeSales[ing.id] || 0;
    if (!dayAudit[ing.id]) {
      dayAudit[ing.id] = { start: ing.stock, end: ing.stock };
    }
    const entry = dayAudit[ing.id];
    const expected = Math.max(0, entry.start - sold);
    const discrepancy = entry.end - expected;
    const isFlagged = discrepancy < 0;

    return `
      <div class="audit-card ${isFlagged ? 'flagged' : ''}">
        <div>
          <div class="audit-name" style="font-weight: 800; font-size: 14px; color: var(--text);">${escHtml(ing.name)}</div>
          <div class="audit-unit" style="font-size: 11px; color: var(--muted); font-weight: 600;">Unité : ${ing.unit}</div>
        </div>
        <div class="audit-input" style="display: flex; flex-direction: column; gap: 4px;">
          <label style="font-size: 10px; font-weight: 800; color: var(--muted); text-transform: uppercase;">Début (4 AM)</label>
          <input type="number" min="0" value="${entry.start}" onchange="updateShiftAudit('${ing.id}', 'start', this.value)" style="width: 80px; padding: 6px; border: 1px solid var(--line); border-radius: 8px; font-weight: 800;" />
        </div>
        <div class="audit-stat" style="display: flex; flex-direction: column; gap: 2px;">
          <span style="font-size: 10px; font-weight: 800; color: var(--muted); text-transform: uppercase;">Ventes</span>
          <span style="color: var(--accent); font-weight: 900; font-size: 13px;">- ${sold} ${ing.unit}</span>
        </div>
        <div class="audit-stat" style="display: flex; flex-direction: column; gap: 2px;">
          <span style="font-size: 10px; font-weight: 800; color: var(--muted); text-transform: uppercase;">Attendu</span>
          <strong style="color: var(--text); font-size: 13px; font-weight: 800;">${expected} ${ing.unit}</strong>
        </div>
        <div class="audit-input" style="display: flex; flex-direction: column; gap: 4px;">
          <label style="font-size: 10px; font-weight: 800; color: var(--muted); text-transform: uppercase;">Fin (2 PM)</label>
          <input type="number" min="0" value="${entry.end}" onchange="updateShiftAudit('${ing.id}', 'end', this.value)" style="width: 80px; padding: 6px; border: 1px solid var(--line); border-radius: 8px; font-weight: 800;" />
        </div>
        <div class="audit-stat" style="grid-column: 1/-1; display:flex; flex-direction:row; justify-content:space-between; margin-top:8px; padding-top:8px; border-top:1px dashed var(--line); align-items:center;">
          <span style="font-weight:900; font-size:11px; color:var(--muted);">CONCORDANCE DES STOCKS</span>
          <span style="font-weight:900; font-size:13px; display:inline-flex; align-items:center; gap:4px; color:${discrepancy === 0 ? 'var(--green)' : discrepancy > 0 ? 'var(--green)' : 'var(--red)'};">
            ${discrepancy === 0 
              ? `<i data-lucide="check-circle-2" style="width:14px; height:14px;"></i> Conforme (0)` 
              : discrepancy > 0 
                ? `<i data-lucide="plus-circle" style="width:14px; height:14px;"></i> +${discrepancy} ${ing.unit} (Surplus)` 
                : `<i data-lucide="alert-triangle" style="width:14px; height:14px;"></i> ${discrepancy} ${ing.unit} (Vol / Perte)`}
          </span>
        </div>
      </div>
    `;
  }).join("");
  lucide.createIcons();
}

function renderAdminPanel() {
  if (activeAdminTab === "recette") {
    renderStats();
    renderRecetteTab();
  } else if (activeAdminTab === "audit") {
    renderAuditTab();
  } else if (activeAdminTab === "produits") {
    renderCatalogAdmin();
  } else if (activeAdminTab === "systeme") {
    renderSettingsCashiers();
    renderHistory();
  } else if (activeAdminTab === "logs") {
    renderAuditLogs();
  }
}
window.renderAdminPanel = renderAdminPanel;


function renderSettingsCashiers() {
  const listContainer = $("settings-cashiers-list");
  if (cashiers.length === 0) {
    listContainer.innerHTML = `<span style="font-size: 12px; color: var(--muted); text-align: center; display: block; padding: 12px;">Aucun caissier configuré.</span>`;
    return;
  }
  listContainer.innerHTML = cashiers.map(c => `
    <div style="display: flex; justify-content: space-between; align-items: center; background: var(--soft-2); padding: 8px 12px; border-radius: 10px; border: 1px solid var(--line);">
      <span style="font-weight: 800; font-size: 13px;">${escHtml(c.name)}</span>
      <button class="small-btn" onclick="triggerDeleteCashier('${c.id}')" style="background: transparent; color: var(--red); border: 0; padding: 4px 8px; font-weight: 900;">Supprimer</button>
    </div>
  `).join("");
}

function renderCatalogAdmin() {
  menu = loadCatalog();
  const list = $("catalogList");
  if (!list) return;

  if (!menu.length) {
    list.innerHTML = `<span style="font-size: 12px; color: var(--muted); text-align: center; display: block; padding: 12px;">Aucun produit configuré.</span>`;
    return;
  }

  list.innerHTML = menu.map(item => {
    const hasStock = item.stock !== null;
    const statusClass = hasStock && item.stock <= 0 ? "stock-out" : hasStock && item.stock <= item.lowStock ? "stock-low" : "";
    return `
      <div class="catalog-row ${statusClass}">
        <div>
          <div class="catalog-name">${escHtml(item.name)}</div>
          <div class="catalog-meta">${escHtml(item.category)} · ${dt(item.price)} · ${hasStock ? "stock suivi" : "stock libre"}</div>
        </div>
        <div class="stock-controls">
          ${hasStock ? `<button data-stock-minus="${item.id}">−</button>` : `<button data-stock-track="${item.id}" title="Suivre le stock">Suivi</button>`}
          <span class="stock-count">${hasStock ? item.stock : "∞"}</span>
          ${hasStock ? `<button data-stock-plus="${item.id}">+</button>` : `<button data-stock-track="${item.id}" title="Suivre le stock">+</button>`}
          <button class="stock-free-btn ${hasStock ? "" : "active"}" data-stock-free="${item.id}" title="Stock libre / illimité">∞ Libre</button>
        </div>
      </div>
    `;
  }).join("");
}

function addCatalogProduct() {
  const category = $("productCategory").value.trim();
  const name = $("productName").value.trim();
  const price = Number($("productPrice").value);
  const stockRaw = $("productStock").value.trim();

  if (!category || !name || !price || price <= 0) {
    showToast("Produit incomplet");
    return;
  }

  const product = normalizeProduct({
    id: "p_" + Date.now(),
    category,
    name,
    price,
    stock: stockRaw === "" ? null : Number(stockRaw),
    active: true
  });

  menu.push(product);
  saveCatalog();
  $("productName").value = "";
  $("productPrice").value = "";
  $("productStock").value = "";
  renderTabs();
  renderMenu();
  renderCatalogAdmin();
  showToast("Produit ajouté");
}

function adjustStock(id, delta) {
  menu = loadCatalog();
  const item = menu.find(product => product.id === id);
  if (!item) return;
  if (item.stock === null) item.stock = 0;
  const before = item.stock;
  item.stock = Math.max(0, item.stock + delta);
  saveCatalog();
  appendStockEvent({
    type: "manual",
    date: today,
    itemId: item.id,
    name: item.name,
    category: item.category,
    before,
    delta,
    after: item.stock
  });
  renderMenu();
  renderCatalogAdmin();
}

function setStockTracking(id, shouldTrack) {
  menu = loadCatalog();
  const item = menu.find(product => product.id === id);
  if (!item) return;
  const before = item.stock;
  item.stock = shouldTrack ? (Number.isFinite(Number(item.stock)) ? Math.max(0, Number(item.stock)) : 0) : null;
  saveCatalog();
  appendStockEvent({
    type: shouldTrack ? "track" : "free",
    date: today,
    itemId: item.id,
    name: item.name,
    category: item.category,
    before,
    delta: 0,
    after: item.stock
  });
  renderMenu();
  renderCatalogAdmin();
  showToast(shouldTrack ? "Stock suivi activé" : "Stock libre activé");
}

function renderTabs() {
  menu = loadCatalog();
  const cats = ["Tous", ...new Set(menu.filter(item => item.active).map(item => item.category))];
  $("tabs").innerHTML = cats.map(cat => `
    <button class="tab ${cat === active ? "active" : ""}" data-cat="${cat}">${escHtml(cat)}</button>
  `).join("");
}

// HIGHLIGHT MATCHING CHARACTERS IN MENUX SEARCH (UX Breakthrough)
function escapeRegExp(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function renderMenu() {
  menu = loadCatalog();
  const q = cleanStr(query);
  const items = menu.filter(item => {
    if (!item.active) return false;
    const okCat = active === "Tous" || item.category === active;
    const okSearch = !q || cleanStr(item.name).includes(q) || cleanStr(item.category).includes(q);
    return okCat && okSearch;
  });

  if (!items.length) {
    $("grid").innerHTML = `<div class="empty" style="grid-column:1/-1">Aucun produit trouvé</div>`;
    return;
  }

  const escapedQ = q ? escHtml(q) : "";
  $("grid").innerHTML = items.map(item => {
    let displayName = escHtml(item.name);
    if (q) {
      const regex = new RegExp(`(${escapeRegExp(q)})`, "gi");
      displayName = displayName.replace(regex, `<mark class="highlight">$1</mark>`);
    }
    const hasStock = item.stock !== null;
    const out = hasStock && item.stock <= 0;
    const low = hasStock && item.stock > 0 && item.stock <= item.lowStock;
    const stockLabel = hasStock ? `<span class="stock-badge ${out ? "out" : low ? "low" : ""}">${out ? "Rupture" : `${item.stock} en stock`}</span>` : "";
    return `
      <button class="item ${out ? "is-out" : ""}" data-add="${item.id}" ${out ? "disabled" : ""}>
        <span class="name">${displayName}</span>
        ${stockLabel}
        <span class="price">${dt(item.price)}</span>
      </button>
    `;
  }).join("");
}

function renderCart() {
  lastCartActivity = Date.now();
  $("cartList").innerHTML = cart.length ? cart.map(item => `
    <div class="row">
      <div>
        <div class="row-title">${escHtml(item.name)}</div>
        <div class="row-sub">${dt(item.price)} × ${item.qty} = ${dt(item.price * item.qty)}</div>
      </div>
      <div class="qty">
        <button data-minus="${item.id}">−</button>
        <div>${item.qty}</div>
        <button data-plus="${item.id}">+</button>
      </div>
    </div>
  `).join("") : `<div class="empty">Panier vide</div>`;

  const subtotal = cartSubtotal();
  const discount = cartDiscount();
  const total = cartTotal();
  const paid = Number(paidBuffer || $("paid").value) || 0;
  const diff = paid - total;

  $("ticketId").textContent = ticketCode();
  $("cartCount").textContent = cartCount();
  if ($("subtotal")) $("subtotal").textContent = dt(subtotal);
  if ($("discountTotal")) $("discountTotal").textContent = discount > 0 ? `-${dt(discount)}` : dt(0);
  $("total").textContent = dt(total);
  $("change").textContent = dt(Math.abs(diff));
  $("changeBox").classList.toggle("bad", diff < 0);
  $("changeBox").firstElementChild.textContent = diff < 0 ? "Reste" : "Monnaie";

  $("done").disabled = !cart.length;
  $("printBtn").disabled = !cart.length;
  $("undoBtn").disabled = !lastAction;
  $("clear").disabled = !cart.length;
  if ($("holdBtn")) $("holdBtn").disabled = !cart.length;

  renderCashSuggestions();
  renderReceiptFromCart();
  renderStats();
}

function getRevenueByMethod(method) {
  return data.orders
    .filter(o => (o.paymentMethod || "Espèces") === method)
    .reduce((sum, o) => sum + o.total, 0);
}

function renderStats() {
  if ($("statOrders")) $("statOrders").textContent = data.orders.length;
  if ($("statRevenue")) $("statRevenue").textContent = dt(dayRevenue());
  if ($("statItems")) $("statItems").textContent = dayItems();
  if ($("shiftJourRevenue")) $("shiftJourRevenue").textContent = dt(shiftJourRevenue());
  if ($("shiftNuitRevenue")) $("shiftNuitRevenue").textContent = dt(shiftNuitRevenue());

  // Cash-only breakdown metrics
  const totalRev = dayRevenue();
  const cashRev = totalRev;
  const cashPct = totalRev > 0 ? 100 : 0;

  if ($("statPayCash")) $("statPayCash").textContent = `${dt(cashRev)} (${cashPct}%)`;
  if ($("barPayCash")) $("barPayCash").style.width = `${cashPct}%`;
}

function getPaymentBadge(method) {
  const m = method || "Espèces";
  return `<span style="padding: 2px 6px; border-radius: 6px; font-size: 10px; font-weight: 800; text-transform: uppercase; margin-left: 4px; background: var(--green-bg); color: var(--green);">${m}</span>`;
}

function renderOrderDiscountPreview(order) {
  if (!(order.discount > 0)) return "";
  return `
    <div style="display: flex; justify-content: space-between; font-size: 11px; color: var(--muted);">
      <span>Remise</span>
      <span>-${dt(order.discount)}</span>
    </div>
  `;
}

function renderOrderMeta(order, cashier, badge) {
  const table = order.tableRef ? ` • <span>${escHtml(order.tableRef)}</span>` : "";
  return `<span>${order.time}</span> • <span>${escHtml(order.orderMode || "Sur place")}</span>${table} • <span>caissier: ${escHtml(cashier)}</span> ${badge}`;
}

function renderOrderItemsPreview(order) {
  return order.items.map(item => `
    <div style="display: flex; justify-content: space-between; gap: 10px;">
      <span>${item.qty}x ${escHtml(item.name)}</span>
      <span>${dt(item.price * item.qty)}</span>
    </div>
  `).join("");
}

function renderHistory() {
  const q = cleanStr(historyQuery);
  let orders = [...data.orders].reverse();

  if (q) {
    orders = orders.filter(order => {
      const inItems = order.items.some(item => cleanStr(item.name).includes(q));
      const inBase = cleanStr(`${order.code} ${order.time} ${order.total} ${(order.cashier || '')} ${(order.paymentMethod || '')} ${(order.orderMode || '')} ${(order.tableRef || '')}`).includes(q);
      return inItems || inBase;
    });
  }

  const listContainer = $("historyList");
  if (!listContainer) return;

  listContainer.innerHTML = orders.length ? orders.map(order => {
    const orderCashier = order.cashier || "Inconnu";
    const badge = getPaymentBadge(order.paymentMethod);
    return `
      <article class="order" style="border: 1px solid var(--line); border-radius: 14px; background: var(--card); overflow: hidden; margin-bottom: 8px;">
        <div class="order-main" style="display: grid; grid-template-columns: auto 1fr auto auto; gap: 8px; align-items: center; padding: 10px;">
          <div class="order-code" style="font-weight: 900; color: var(--accent);">${order.code}</div>
          <div style="display: flex; flex-direction: column;">
            <div class="order-meta" style="color: var(--muted); font-size: 12px; font-weight: 700; display: flex; align-items: center; gap: 4px;">
              ${renderOrderMeta(order, orderCashier, badge)}
            </div>
          </div>
          <div class="order-total" style="font-weight: 800; font-size: 16px; font-family: var(--font-heading);">${dt(order.total)}</div>
          <button class="order-btn" data-reprint="${order.id}" style="padding: 6px 10px; font-size: 11px; font-weight: 800; border-radius: 8px; border: 1px solid var(--line); background: var(--soft-2); color: var(--text); cursor: pointer; transition: var(--transition); display: inline-flex; align-items: center; gap: 4px;"><i data-lucide="printer" style="width: 12px; height: 12px;"></i> Print</button>
        </div>
        <details class="order-details" style="margin-top: 2px;">
          <summary style="cursor: pointer; color: var(--accent); font-weight: 800; font-size: 12px; outline: none; padding: 4px 10px 8px;">🧾 Aperçu du Ticket Réel</summary>
          <div class="details-items" style="background: #ffffff; color: #1c1512; border: 1px solid var(--line); border-radius: 12px; padding: 16px; font-family: monospace; font-size: 12px; margin: 0 10px 10px; box-shadow: inset 0 2px 8px rgba(0,0,0,0.03); position: relative; overflow: hidden; display: flex; flex-direction: column;">
            <div style="text-align: center; border-bottom: 1px dashed #241c17; padding-bottom: 8px; margin-bottom: 8px; font-family: var(--font-heading); font-weight: 800;">
              <span style="font-size: 13px; display: block; letter-spacing: 0.05em; font-family: var(--font-display);">ZINA COFFEE</span>
              <span style="font-size: 10px; font-weight: 700; color: var(--muted); display: block;">Tunis • Oued Ellil</span>
              <span style="font-size: 10px; font-weight: 700; color: var(--muted); display: block;">${escHtml(order.orderMode || "Sur place")}${order.tableRef ? " • " + escHtml(order.tableRef) : ""}</span>
            </div>
            <div style="display: flex; flex-direction: column; gap: 4px;">
              ${renderOrderItemsPreview(order)}
            </div>
            <div style="border-top: 1px dashed #241c17; margin: 8px 0; padding-top: 8px;">
              <div style="display: flex; justify-content: space-between; font-size: 11px; color: var(--muted);">
                <span>Sous-total</span>
                <span>${dt(order.subtotal ?? order.total)}</span>
              </div>
              ${renderOrderDiscountPreview(order)}
              <div style="display: flex; justify-content: space-between; font-weight: 800; font-size: 13px;">
                <span>TOTAL</span>
                <span>${dt(order.total)}</span>
              </div>
            </div>
            <div style="border-top: 1px dashed #241c17; padding-top: 8px; margin-top: 8px; text-align: center; font-size: 10px; color: var(--muted); font-family: var(--font-heading); font-weight: 700;">
              <span>Ticket ${order.code} • ${order.dateText}</span>
              <span style="display: block; margin-top: 2px;">Merci pour votre visite !</span>
            </div>
          </div>
        </details>
      </article>
    `;
  }).join("") : `<div class="empty">Aucune vente enregistrée</div>`;
  lucide.createIcons();
}

// High fidelity print preview ticket (thermal formatted output)
function renderReceipt(order) {
  if (!order) return;
  currentReceiptOrder = order;
  $("receipt").innerHTML = `
    <h2>ZINA COFFEE</h2>
    <p>Oued Ellil • Tunis</p>
    <p>${order.dateText}</p>
    <p>Ticket ${order.code} • ${order.paymentMethod || "Espèces"}</p>
    <p>${order.orderMode || "Sur place"}${order.tableRef ? " • " + escHtml(order.tableRef) : ""}${order.guestCount ? " • " + order.guestCount + " couverts" : ""}</p>
    <p>Caissier: ${escHtml(order.cashier || "Inconnu")}</p>
    <div class="sep"></div>
    ${order.items.map(item => `
      <div class="r-row"><span>${item.qty} x ${escHtml(item.name)}</span><span>${dt(item.price * item.qty)}</span></div>
    `).join("")}
    <div class="sep"></div>
    <div class="r-row r-total"><span>TOTAL</span><span>${dt(order.total)}</span></div>
    <div class="sep"></div>
    <p style="margin: 8px 0 2px; font-weight: 800; font-size: 11px;">SCAN TO ORDER / SCANNEZ POUR COMMANDER</p>
    <div style="text-align: center; margin: 4px 0;"><img src="https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=https://zina-coffee.web.app" style="width:70px; height:70px;" /></div>
    <p>Merci • صحة وبالشفاء</p>
  `;
}

function renderReceiptFromCart() {
  const now = new Date();
  renderReceipt({
    id: "preview",
    code: ticketCode(),
    dateText: now.toLocaleDateString("fr-FR") + " " + now.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }),
    items: cart,
    subtotal: cartSubtotal(),
    discount: cartDiscount(),
    total: cartTotal(),
    paid: Number(paidBuffer || $("paid").value) || 0,
    change: Math.max(0, (Number(paidBuffer || $("paid").value) || 0) - cartTotal()),
    cashier: activeCashier ? activeCashier.name : "Inconnu",
    paymentMethod: "Espèces",
    orderMode: currentOrderMode
  });
}

function renderAll() {
  renderTabs();
  renderMenu();
  renderCart();
  renderHistory();
  renderHoldsTray();
  renderCatalogAdmin();
}

function addItem(id) {
  menu = loadCatalog();
  const product = menu.find(item => item.id === id) || cart.find(item => item.id === id);
  if (!product) return;
  if (product.stock !== null) {
    const alreadyInCart = cart.find(item => item.id === id)?.qty || 0;
    if (alreadyInCart >= product.stock) {
      showToast("Stock insuffisant");
      playTactileBeep('error');
      return;
    }
  }

  playTactileBeep('click');
  const found = cart.find(item => item.id === id);
  lastAction = { type: "add", id };
  if (found) found.qty += 1;
  else cart.push({ ...product, qty: 1 });
  renderCart();
}

function addCustom() {
  const name = $("customName").value.trim();
  const price = Number($("customPrice").value);
  if (!name || !price || price <= 0) {
    showToast("Article rapide incomplet");
    return;
  }

  playTactileBeep('click');
  const id = "c" + Date.now();
  cart.push({ id, category: "Rapide", name, price, qty: 1 });
  lastAction = { type: "custom", id };
  $("customName").value = "";
  $("customPrice").value = "";
  $("saveToMenuBtn").style.display = "none";
  renderCart();
  showToast("Article ajouté");
}

function saveToMenu() {
  const name = $("customName").value.trim();
  const price = Number($("customPrice").value);
  if (!name || !price || price <= 0) {
    showToast("Remplis nom et prix d'abord");
    return;
  }
  playTactileBeep('success');
  const product = normalizeProduct({ id: "p_" + Date.now(), category: "Menu", name, price, stock: null, active: true });
  menu.push(product);
  saveCatalog();
  renderTabs();
  renderMenu();
  renderCatalogAdmin();
  showToast(name + " ajouté au menu");
  $("saveToMenuBtn").style.display = "none";
}

function changeQty(id, delta) {
  playTactileBeep('click');
  const item = cart.find(row => row.id === id);
  if (!item) return;
  lastAction = { type: delta > 0 ? "plus" : "minus", id, previousQty: item.qty, snapshot: { ...item } };
  item.qty += delta;
  if (delta < 0) {
    logAuditEvent("Retour Article", `Retiré 1x ${item.name} du ticket en cours (valeur: ${dt(item.price)})`);
  }
  cart = cart.filter(row => row.qty > 0);
  renderCart();
}

function undo() {
  playTactileBeep('click');
  if (!lastAction) return;
  const item = cart.find(row => row.id === lastAction.id);
  const name = item ? item.name : (lastAction.snapshot ? lastAction.snapshot.name : lastAction.id);
  logAuditEvent("Annulation Action", `Retour/Annulation de l'action "${lastAction.type}" sur l'article "${name}".`);

  if (["add", "plus", "custom"].includes(lastAction.type) && item) {
    item.qty -= 1;
    cart = cart.filter(row => row.qty > 0);
  }

  if (lastAction.type === "minus") {
    if (item) item.qty = lastAction.previousQty;
    else cart.push(lastAction.snapshot);
  }

  lastAction = null;
  renderCart();
}

function validateCartStock() {
  for (const item of cart) {
    const product = menu.find(row => row.id === item.id);
    if (product && product.stock !== null && item.qty > product.stock) {
      showToast(`Stock insuffisant: ${item.name}`);
      playTactileBeep('error');
      return false;
    }
  }
  return true;
}

function closeOrder(printAfter = false) {
  if (!cart.length) return;
  if (!validateCartStock()) return;
  const total = cartTotal();
  const rawPaid = (paidBuffer || $("paid").value || "").trim();
  let paid = Number(rawPaid);

  // If amount received is empty, blank, or 0, default to exact payment automatically without prompts
  if (!rawPaid || isNaN(paid) || paid === 0) {
    paid = total;
    executeOrderSave(paid, total, printAfter);
    return;
  }

  if (paid < total) {
    showCustomConfirm("Montant reçu inférieur au total. Enregistrer comme paiement exact ?").then(ok => {
      if (!ok) return;
      paid = total;
      executeOrderSave(paid, total, printAfter);
    });
  } else {
    executeOrderSave(paid, total, printAfter);
  }
}

function applyStockMovement(items) {
  menu = loadCatalog();
  let changed = false;
  const movements = [];
  items.forEach(item => {
    const product = menu.find(row => row.id === item.id);
    if (!product || product.stock === null) return;
    const before = product.stock;
    product.stock = Math.max(0, product.stock - item.qty);
    movements.push({
      itemId: product.id,
      name: product.name,
      category: product.category,
      before,
      sold: item.qty,
      after: product.stock
    });
    changed = true;
  });
  if (changed) saveCatalog();
  return movements;
}

function executeOrderSave(paid, total, printAfter) {
  playTactileBeep('success');
  const now = new Date();
  const subtotal = cartSubtotal();
  const discount = cartDiscount();
  const stockMovements = applyStockMovement(cart);
  
  // DEDUCT RAW MATERIAL INGREDIENTS
  deductIngredientsForCart(cart);

  const order = {
    id: "o" + Date.now(),
    code: ticketCode(),
    date: today,
    time: now.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }),
    dateText: now.toLocaleDateString("fr-FR") + " " + now.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }),
    items: cart.map(item => ({ id: item.id, name: item.name, price: item.price, qty: item.qty })),
    subtotal,
    discount,
    total,
    paid,
    change: Math.max(0, paid - total),
    cashier: activeCashier ? activeCashier.name : "Inconnu",
    paymentMethod: "Espèces",
    orderMode: currentOrderMode,
    stockMovements
  };

  data.orders.push(order);
  data.sequence += 1;
  saveData();
  logAuditEvent("Encaissement", `Commande ${order.code} finalisée d'un montant de ${dt(order.total)} (Reçu: ${dt(order.paid)}, Mode: ${order.orderMode})`);
  if (stockMovements.length) {
    stockMovements.forEach(m => {
      appendStockEvent({
        type: "sale",
        date: today,
        orderId: order.id,
        code: order.code,
        itemId: m.itemId,
        name: m.name,
        category: m.category,
        before: m.before,
        after: m.after,
        delta: -m.sold,
        note: "vente ticket " + order.code
      });
    });
  }
  renderReceipt(order);

  // Clean hold ticket if this was a hold draft
  const activeHold = holds.find(h => JSON.stringify(h.cart) === JSON.stringify(cart));
  if (activeHold) {
    holds = holds.filter(h => h.id !== activeHold.id);
  }

  cart = [];
  lastAction = null;
  activePaymentMethod = "Espèces";
  $("paid").value = "";
  paidBuffer = "";
  resetTicketMeta();
  renderAll();
  showToast("Commande enregistrée");

  if (printAfter) window.print();
}

function clearCart() {
  if (!cart.length) return;
  const total = cartTotal();
  const count = cartCount();
  const itemsText = cart.map(i => `${i.qty}x ${i.name}`).join(", ");
  
  showCustomConfirm("Vider le ticket actuel ?").then(ok => {
    if (!ok) return;
    playTactileBeep('click');
    logAuditEvent("Ticket Vider", `Panier entièrement vidé par le caissier. Valeur: ${dt(total)} (Contenait: ${count} articles [${itemsText}])`);
    cart = [];
    lastAction = null;
    $("paid").value = "";
    paidBuffer = "";
    resetTicketMeta();
    renderCart();
  });
}

function resetDay() {
  showCustomPinPrompt("Admin PIN :").then(caissePin => {
    if (caissePin === null) return;
    if (!isOwnerPin(caissePin)) {
      playTactileBeep('error');
      failedPinAttempts++;
      if (failedPinAttempts >= 3) {
        triggerNewLockout();
      } else {
        showToast(`PIN incorrect (${3 - failedPinAttempts} restants)`);
      }
      return;
    }
    failedPinAttempts = 0; // Reset on success
    saveLockoutCount(0); // Reset lockout count on successful entry

    showCustomConfirm("Êtes-vous sûr de vouloir réinitialiser l'historique du jour ?").then(ok => {
      if (!ok) return;
      playTactileBeep('success');
      logAuditEvent("Reset Journée", "Réinitialisation complète de l'historique des ventes du jour.");
      data.orders = [];
      data.sequence = 1;
      saveData();
      cart = [];
      lastAction = null;
      $("paid").value = "";
      paidBuffer = "";
      resetTicketMeta();
      renderAll();
      showToast("Jour reset");
      closeModal("settings-modal");
    });
  });
}

function printCurrent() {
  if (!cart.length) return;
  playTactileBeep('click');
  renderReceiptFromCart();
  window.print();
}

// Print single receipt from order archives
function printOrder(id) {
  playTactileBeep('click');
  const order = data.orders.find(row => row.id === id);
  if (!order) return;
  renderReceipt(order);
  window.print();
}

function printLast() {
  const last = data.orders[data.orders.length - 1];
  if (!last) {
    showToast("Pas de dernier ticket");
    return;
  }
  playTactileBeep('click');
  renderReceipt(last);
  window.print();
}

function buildCSV() {
  const rows = [["ticket", "date", "time", "caissier", "type_commande", "table_client", "items", "subtotal", "discount", "total", "paid", "change", "mode_paiement"]];
  data.orders.forEach(order => {
    rows.push([
      order.code,
      order.date,
      order.time,
      order.cashier || "Inconnu",
      order.orderMode || "Sur place",
      order.tableRef || "",
      order.items.map(item => `${item.qty}x ${item.name}`).join(" | "),
      order.subtotal ?? order.total,
      order.discount || 0,
      order.total,
      order.paid,
      order.change,
      order.paymentMethod || "Espèces"
    ]);
  });
  return rows.map(row => row.map(csvEscape).join(",")).join("\n");
}

function exportCSV() {
  if (!data.orders.length) {
    showToast("Historique vide");
    return;
  }

  playTactileBeep('success');
  const csv = buildCSV();
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `menux-caisse-${today}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

function bindEvents() {
  $("tabs").addEventListener("click", event => {
    const btn = event.target.closest("[data-cat]");
    if (!btn) return;
    playTactileBeep('click');
    active = btn.dataset.cat;
    renderTabs();
    renderMenu();
  });

  $("grid").addEventListener("click", event => {
    const btn = event.target.closest("[data-add]");
    if (!btn) return;
    addItem(btn.dataset.add);
  });

  $("cartList").addEventListener("click", event => {
    const plus = event.target.closest("[data-plus]");
    const minus = event.target.closest("[data-minus]");
    if (plus) changeQty(plus.dataset.plus, 1);
    if (minus) changeQty(minus.dataset.minus, -1);
  });

  $("historyList").addEventListener("click", event => {
    const btn = event.target.closest("[data-reprint]");
    if (!btn) return;
    printOrder(btn.dataset.reprint);
  });

  $("search").addEventListener("input", event => {
    query = event.target.value;
    renderMenu();
  });

  $("historySearch").addEventListener("input", event => {
    historyQuery = event.target.value;
    renderHistory();
  });

  const orderModeTray = $("orderModeTray");
  if (orderModeTray) {
    orderModeTray.addEventListener("click", event => {
      const btn = event.target.closest("[data-order-mode]");
      if (!btn) return;
      playTactileBeep('click');
      currentOrderMode = btn.dataset.orderMode;
      orderModeTray.querySelectorAll(".mode-btn").forEach(modeBtn => {
        modeBtn.classList.toggle("active", modeBtn === btn);
      });
    });
  }

  $("showAllBtn").onclick = () => {
    playTactileBeep('click');
    active = "Tous";
    query = "";
    $("search").value = "";
    renderTabs();
    renderMenu();
  };

  $("addCustomBtn").onclick = addCustom;
  $("saveToMenuBtn").onclick = saveToMenu;
  $("customName").addEventListener("input", () => {
    const has = ($("customName").value.trim() && Number($("customPrice").value) > 0);
    $("saveToMenuBtn").style.display = has ? "flex" : "none";
  });
  $("customPrice").addEventListener("input", () => {
    const has = ($("customName").value.trim() && Number($("customPrice").value) > 0);
    $("saveToMenuBtn").style.display = has ? "flex" : "none";
  });
  $("customPrice").addEventListener("keydown", event => {
    if (event.key === "Enter") addCustom();
  });

  $("addProductBtn").onclick = addCatalogProduct;
  $("catalogList").addEventListener("click", event => {
    const plus = event.target.closest("[data-stock-plus]");
    const minus = event.target.closest("[data-stock-minus]");
    const track = event.target.closest("[data-stock-track]");
    const free = event.target.closest("[data-stock-free]");
    if (plus) adjustStock(plus.dataset.stockPlus, 1);
    if (minus) adjustStock(minus.dataset.stockMinus, -1);
    if (track) setStockTracking(track.dataset.stockTrack, true);
    if (free) setStockTracking(free.dataset.stockFree, false);
  });

  $("paid").addEventListener("click", showPaidNumpad);

  // Close numpad when clicking outside
  document.addEventListener("click", event => {
    const np = $("paidNumpad");
    if (np && np.style.display !== "none" && !event.target.closest("#paidNumpad") && !event.target.closest("#paid")) {
      np.style.display = "none";
    }
  });

  $("done").onclick = () => closeOrder(false);
  $("printBtn").onclick = printCurrent;
  $("undoBtn").onclick = undo;
  $("clear").onclick = clearCart;
  if ($("holdBtn")) $("holdBtn").onclick = holdCurrentTicket;
  if ($("zoomOutBtn")) $("zoomOutBtn").onclick = zoomOut;
  if ($("zoomInBtn")) $("zoomInBtn").onclick = zoomIn;
  if ($("zoomResetBtn")) $("zoomResetBtn").onclick = resetZoom;
  
  $("settingsBtn").onclick = () => {
    const now = Date.now();
    if (lockoutUntil && now < lockoutUntil) {
      const secondsLeft = Math.ceil((lockoutUntil - now) / 1000);
      if (secondsLeft < 60) {
        showToast(`Bloqué! Attendez ${secondsLeft}s`);
      } else {
        const minutesLeft = Math.ceil(secondsLeft / 60);
        showToast(`Bloqué! Attendez ${minutesLeft} min`);
      }
      playTactileBeep('error');
      return;
    }

    if (isActiveSuperAdmin()) {
      failedPinAttempts = 0;
      saveLockoutCount(0);
      openModal("settings-modal");
      return;
    }

    showCustomPinPrompt("Admin PIN :").then(caissePin => {
      if (caissePin === null) return;
      if (isOwnerPin(caissePin)) {
        failedPinAttempts = 0; // Reset on success
        saveLockoutCount(0); // Reset lockout count on successful entry
        openModal("settings-modal");
      } else {
        playTactileBeep('error');
        failedPinAttempts++;
        if (failedPinAttempts >= 3) {
          triggerNewLockout();
        } else {
          showToast(`PIN incorrect (${3 - failedPinAttempts} restants)`);
        }
      }
    });
  };
  $("lockBtn").onclick = lockPOS;

  $("modalResetDayBtn").onclick = resetDay;
  $("createFirstCashierBtn").onclick = triggerCreateCashier;

  $("exportBtn").onclick = exportCSV;
  $("printLastBtn").onclick = printLast;

  $("whatsappReportBtn").onclick = () => {
    playTactileBeep('success');
    const totalCA = dayRevenue();
    const wages = getTodayWages();
    const starting = getTodayStartingCash();
    const closing = getTodayClosingCash();
    const expected = starting + totalCA - wages;
    const discrepancy = closing - expected;
    
    // Ingredients summary
    const ingredients = loadIngredients();
    const audits = loadAudits();
    const dayAudit = audits[today] || {};
    const recipeSales = {};
    data.orders.forEach(o => {
      (o.items || []).forEach(item => {
        const recipe = RECIPES[item.name];
        if (!recipe) return;
        recipe.forEach(step => {
          if (!recipeSales[step.ingredientId]) recipeSales[step.ingredientId] = 0;
          recipeSales[step.ingredientId] += step.qty * (+item.qty || 0);
        });
      });
    });
    
    const ingSummary = ingredients.map(ing => {
      const sold = recipeSales[ing.id] || 0;
      const entry = dayAudit[ing.id] || { start: ing.stock, end: ing.stock };
      const expectedIng = Math.max(0, entry.start - sold);
      const diffIng = entry.end - expectedIng;
      return `${ing.name}: ${diffIng >= 0 ? '+' : ''}${diffIng} ${ing.unit}`;
    }).join(" | ");

    const text = `*ZINA COFFEE - RAPPORT DU ${today}*\n\n` +
      `• *Chiffre d'Affaires:* ${dt(totalCA)}\n` +
      `• *Salaires:* ${dt(wages)}\n` +
      `• *Bénéfice Net:* ${dt(totalCA - wages)}\n` +
      `• *Fonds de Caisse:* ${dt(starting)}\n` +
      `• *Espèces Réelles:* ${dt(closing)}\n` +
      `• *Écart de Caisse flouse:* ${discrepancy >= 0 ? '+' : ''}${dt(discrepancy)}\n` +
      `• *Écart Ingrédients:* ${ingSummary}`;

    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, "_blank");
  };

  $("telegramBroadcastBtn").onclick = () => {
    playTactileBeep('success');
    sendTelegramNotification(buildDailyTelegramReport());
    showToast("Rapport Telegram envoyé");
  };

  $("clearLogsBtn").onclick = () => {
    showCustomPinPrompt("Admin PIN :").then(caissePin => {
      if (caissePin === null) return;
      if (isOwnerPin(caissePin)) {
        failedPinAttempts = 0;
        saveLockoutCount(0);
        showCustomConfirm("Voulez-vous vraiment effacer tous les logs d'audit ? Cette action est irréversible.").then(ok => {
          if (!ok) return;
          playTactileBeep('success');
          localStorage.removeItem(LOGS_KEY);
          logAuditEvent("Logs Effacés", "L'historique complet d'audit a été effacé par le propriétaire.");
          renderAuditLogs();
          showToast("Logs effacés");
        });
      } else {
        playTactileBeep('error');
        failedPinAttempts++;
        if (failedPinAttempts >= 3) {
          triggerNewLockout();
        } else {
          showToast(`PIN incorrect (${3 - failedPinAttempts} restants)`);
        }
      }
    });
  };

  window.addEventListener("keydown", event => {
    if (event.key === "Escape") {
      clearCart();
      closeModal("settings-modal");
    }
    if (event.key === "Enter" && (document.activeElement === $("paid") || $("paidNumpad").style.display !== "none")) {
      $("paidNumpad").style.display = "none";
      closeOrder(false);
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "p") {
      event.preventDefault();
      printCurrent();
    }
    
    // Lock screen keypad bindings
    if ($("portal-container").style.display !== "none" && $("pin-pad-view").style.display !== "none") {
      if (event.key >= "0" && event.key <= "9") {
        typePinDigit(parseInt(event.key));
      } else if (event.key === "Backspace") {
        deletePinDigit();
      } else if (event.key === "Escape" || event.key === "Delete") {
        clearPinInput();
      }
    }
  });
}

function runSelfTests() {
  const tests = [];
  tests.push({ name: "catalog is available", pass: Array.isArray(menu) && menu.length >= 16 });
  tests.push({ name: "catalog products have stock fields", pass: menu.every(item => Object.prototype.hasOwnProperty.call(item, "stock")) });
  tests.push({ name: "ticket starts at #001", pass: /^#\d{3}$/.test(ticketCode()) });
  tests.push({ name: "dt formats DT", pass: dt(4.5).includes("DT") });
  tests.push({ name: "csv newline is escaped", pass: buildCSV().includes("\n") });
  tests.push({ name: "Caisse PIN verification is defined", pass: typeof MASTER_PIN !== "undefined" });
  tests.push({ name: "discount never exceeds subtotal", pass: cartDiscount() <= cartSubtotal() });

  const failed = tests.filter(test => !test.pass);
  if (failed.length) {
    console.warn("Menux POS Prestige self-tests failed:", failed.map(test => test.name));
  } else {
    console.info("Menux POS Prestige self-tests passed:", tests.length);
  }
}

// Sanitization: Ensure category "Viennoiseries" contains only "Cake" (1.5 DT) and no other items to comply with the master spec
menu = menu.filter(item => {
  if (item.category === "Viennoiseries") {
    return item.name === "Cake";
  }
  return true;
});
// Ensure Cake exists in Viennoiseries
if (!menu.some(item => item.name === "Cake" && item.category === "Viennoiseries")) {
  menu.push(normalizeProduct({ id: "p_cake", category: "Viennoiseries", name: "Cake", price: 1.5, stock: null, active: true }));
}
saveCatalog();

// Initial renders
applyUiZoom();
initTheme();
bindEvents();
updateClock();
setInterval(updateClock, 1000);
renderCashierPortal();
runSelfTests();

// Cross-tab database synchronization event listener
window.addEventListener('storage', (e) => {
  if (e.key === CATALOG_KEY || e.key === STOCK_KEY || e.key === INGREDIENTS_KEY) {
    menu = loadCatalog();
    renderAll();
  }
});

// Initial Lucide Icons population
lucide.createIcons();

// Security Hardening: Disable right-click and developer tool shortcuts to prevent cashiers from inspecting local database
document.addEventListener("contextmenu", event => event.preventDefault());

window.addEventListener("keydown", event => {
  // Disable F12
  if (event.key === "F12") {
    event.preventDefault();
  }
  // Disable Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+Shift+C, Ctrl+Shift+K
  if ((event.ctrlKey || event.metaKey) && event.shiftKey && ["I", "J", "C", "K"].includes(event.key.toUpperCase())) {
    event.preventDefault();
  }
  // Disable Ctrl+U (View Source)
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "u") {
    event.preventDefault();
  }
});
